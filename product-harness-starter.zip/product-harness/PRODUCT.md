# Product / Prompt Lab

Status: example brief, not an implemented application.

## Outcome

A local tool where a developer writes prompts, keeps named revisions, compares saved model outputs, and exports the workspace. Start with labeled sample outputs; connecting a paid model is a separate feature.

## Core journey

Create prompt → save revision → reload → compare two saved outputs → export workspace.

## Initial features

- F01: named revisions persist across a page reload.
- F02: two saved outputs can be selected and compared side by side.
- F03: export/import preserves prompt text, revision IDs, and saved outputs; invalid import shows a useful error without deleting the current workspace.

## Decisions to settle before building

- Storage, framework, and browser support.
- Expected behavior for blank names and duplicate revision names.
- Maximum useful sample output size and comparison behavior on narrow screens.

## Actual project commands

Setup: NOT CONFIGURED
Start: NOT CONFIGURED
Unit/integration checks: NOT CONFIGURED
Browser checks: NOT CONFIGURED
Local URL: NOT CONFIGURED

Replace these fields with commands verified in the chosen project. Never report these placeholders as working commands.

## Scope boundary

Local prototype first. No account system, billing, deployment, or live paid generation in this example scope.

# Sources and evidence boundaries

Checked 2026-10-25. These templates are an original @beamnxw adaptation; they are not an official preset or a benchmarked universal optimum.

- [A] Anthropic / planner, generator, evaluator (2026-03-24): https://www.anthropic.com/research/harness-design-long-running-apps
- [B] Anthropic / multi-session coding harness (2025-11-26): https://www.anthropic.com/research/effective-harnesses-for-long-running-agents
- [C] OpenAI / repository knowledge + feedback (2026-02-11): https://openai.com/index/harness-engineering/
- [D] Harness design / 176 matched settings (2026-09-17): https://arxiv.org/abs/2609.20804
- [E] Evaluating AGENTS.md / revised paper (2026-09-29): https://arxiv.org/abs/2602.11988v3

## What each source contributes

A: separates planning, generation, and evaluation; uses a sprint contract and live browser feedback. Its older experiments used Opus 4.5 and Sonnet 4.5. Do not present their results as Opus 5.5 benchmark results. The fuller harness incurred substantially more runtime and spend; no savings claim is made here.

B: incremental feature work, durable progress artifacts, and a reproducible environment across sessions. A new session needs observed repo state as well as notes.

C: a concise entry map to maintained repository documentation, executable feedback, and mechanically enforced rules. The post describes one OpenAI team's system, not guaranteed behavior in an arbitrary repo.

D: 176 matched settings across four models and two benchmarks, using Nemotron-3 models and Mistral-Medium-3.5. Context, planning, and tool-interface effects were conditional. It did not validate this kit or Claude. The recommendation to keep context lean is a design inference; the exact templates are ours.

E: September 29 revision of Evaluating AGENTS.md. It finds no general success improvement from the tested context files and reports higher average inference cost. It supports evaluating minimal task-relevant instructions rather than auto-generating a long repository overview. It does not establish that every context file is harmful.

## Our design choices

The Prompt Lab example, filenames, selected state fields, separate evaluation context, two-repair starting policy, and evidence-to-revision convention are our adaptation. The kit has not been tested as an autonomous coding agent. Its file integrity and media exports were checked locally; no paid model experiment was run.

## Official code baseline

https://github.com/anthropics/claude-quickstarts/tree/main/autonomous-coding

This is a separate two-role initializer/coder demo. Its documented --max-iterations flag caps agent iterations, not total dollars. Follow its own README, dependency, model, and permission configuration. This kit does not vendor or modify that code.

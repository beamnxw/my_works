# Product-building workflow

- Read PRODUCT.md for the goal, actual commands, and scope.
- Read the selected role file in roles/; follow the agreed CONTRACT.md.
- Read FEATURES.json and HANDOFF.md when starting or resuming work.
- Inspect the current repo and code revision; notes can be stale.
- Build one agreed feature at a time; preserve unrelated work.
- Save full check output and browser evidence under artifacts/<run-id>/.
- Mark a feature pass only after its acceptance checks have evidence at the recorded code revision.
- Keep failures, blockers, and unverified behavior visible.
- Put runtime limits and permissions in the runner, not only in these instructions.
- Review changes before release; do not publish or spend without authorization.

# Feature contract

Feature: F01 — persist named prompt revisions
State: proposed; agree before implementation
Code revision under evaluation: NOT RECORDED

## Behavior

A user enters a prompt and revision name, saves it, reloads the page, and finds the same saved revision. Editing the current prompt does not silently overwrite an earlier saved revision.

## Checks

| ID | Action | Expected observation | Evidence |
|---|---|---|---|
| C01 | Save prompt text under revision v1, then reload | v1 and its exact text remain available | not collected |
| C02 | Edit the current text without saving over v1 | reopening v1 preserves its prior contents | not collected |
| C03 | Try a blank revision name | agreed validation behavior; no corrupt entry | not collected |

## Evaluation report fields

Record feature_id, code_revision, check_id, observed_result, verdict (pass/fail/unverified), evidence_path, and reproduction_steps. Use unverified when a tool or dependency is missing. State whether the browser flow was automated or manually exercised.

## Completion

All agreed checks pass with evidence against the current code revision. Report remaining limits separately. If code changes after evaluation, rerun affected checks; a prior verdict is not evidence for new code.

## Repair policy — our suggested starting policy

At most two repair rounds for this feature before a human reviews the blocker. This is a starting value to tune, not a research result. Enforce it in the human-driven process or runner; this document cannot enforce a limit by itself.

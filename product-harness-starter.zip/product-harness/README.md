# Product Harness / @beamnxw

A file-and-prompt workflow for building a product in verifiable slices. Original synthesis of the sources in SOURCES.md, checked 2026-10-25.

## What this kit contains

Eight workflow files plus this README and SOURCES.md. These are templates, not an installed autonomous runner. They do not launch agents, supply browser tools, enforce budgets, or prove a product works.

## Start with one product

1. Copy this folder into an empty demo project, or merge the individual files into an existing repo without replacing its instructions.
2. Replace PRODUCT.md with your brief. Keep the example only if you want to build Prompt Lab. Choose the stack and record actual setup, start, and test commands there.
3. Give your coding agent CLAUDE.md and roles/PLANNER.md. Review the product scope and the first CONTRACT.md before implementation.
4. Give the builder the agreed contract and roles/BUILDER.md. Build one feature and run the relevant checks.
5. Open a separate evaluator context with roles/EVALUATOR.md, the contract, the current code revision, and access to the running app. Provide a browser tool through your runtime. Do not paste the builder's self-rating into that context.
6. Feed concrete failures back to the builder. The orchestrating human or runtime caps repair attempts. Record a blocker if the cap is reached.
7. Update FEATURES.json and HANDOFF.md after each evaluated feature. Check the current repo state before resuming.

The planner, builder, and evaluator are workflow roles. A person can drive separate sessions, or a runtime can orchestrate them. Independent context reduces shared narrative; it does not make the judge infallible. Runtime permissions and budgets must be implemented outside these prompt files. Release remains a separate human-reviewed step.

## Official runnable baseline

Anthropic's autonomous-coding quickstart is a separate initializer + coding-agent demo, not this three-role adaptation:

https://github.com/anthropics/claude-quickstarts/tree/main/autonomous-coding

After following that repository's prerequisites and configuring its API key, its documented limited-iteration command is:

    python autonomous_agent_demo.py --project-dir ./my_project --max-iterations 3

Run that command from the quickstart's autonomous-coding directory. The iteration limit is not a dollar budget. Its default model and dependencies may differ from your current environment; inspect the repo before running. No paid model calls were made while preparing this kit.

## Example run order

planner → agree contract → builder → evaluator → repair or verified handoff → next feature

Start by verifying F01's edit/save/reload behavior, then F02 comparison, then F03 export/import. Keep the scope small enough that every claimed pass has observable evidence.

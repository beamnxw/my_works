# Handoff

Current feature: F01
Workspace / branch: NOT RECORDED
Current code revision: NOT RECORDED
Working-tree changes: NOT INSPECTED
Last passing checks: NONE RECORDED
Failed / blocked checks: NONE RUN
Evidence directory: NONE CREATED
Attempts used / cap: 0 / 2 repair rounds (suggested policy)
Runtime permission and spend settings: NOT CONFIGURED

## Next action

Review PRODUCT.md, choose the stack, and agree CONTRACT.md. Inspect the real repo before relying on this note.

## End-of-session update

Replace the fields above with observed facts. Record commands actually run, relevant outputs, files changed, unresolved failures, and one concrete next action. Preserve work even when the session stops without a pass.

# Feature ledger

All rows below are examples. Replace or reorder them from the real brief.

| ID | Outcome | State | Contract | Evaluated snapshot | Evidence |
|---|---|---|---|---|---|
| F01 | Create project + persistent task | planned | CONTRACT.md (proposed) | none | not run |
| F02 | Change task status + filter board | planned | not written | none | not run |
| F03 | Export backup + restore test copy | planned | not written | none | not run |

States: planned → ready → building → needs_review → verified. An evaluation can return failed or blocked; record why. The planner sets ready only after the contract is agreed and material prerequisites exist. The builder sets needs_review after self-checks. The evaluator sets verified only for a fully checked snapshot.

When CONTRACT.md is replaced, preserve the completed contract and its report in a project artifact directory chosen by the operator; update this table to the stable paths. Those are generated project records, not additional starter files.

If a later change affects a verified behavior, mark it needs_review and repeat the affected checks. Preserve history and evidence rather than deleting failed outcomes. Never replace missing evidence with an invented pass.

# Active feature contract

Status: proposed example / not yet agreed
Feature: F01 — create a project and persist a task
Code snapshot under evaluation: not built

The planner adapts this example to the actual app and confirms only material open decisions before implementation. Once agreed, record who agreed and when. Do not quietly reduce acceptance checks to make a failure pass.

## Outcome

A user can create a named project, add a named task, and reopen both after a page reload.

## Acceptance checks

| ID | Action | Required observation |
|---|---|---|
| C01 | Create project Alpha | Alpha appears in the project list |
| C02 | Add task Draft homepage to Alpha | Exactly one matching task appears under Alpha |
| C03 | Reload and reopen Alpha | The project and exact task title persist |
| C04 | Submit an empty project or task name | Invalid data is rejected with understandable feedback |
| C05 | Use the primary flow with keyboard navigation | Controls can be reached and activated; focus is visible |
| C06 | Exercise the agreed narrow viewport | Primary controls remain usable and content readable |

## Scope and constraints

No auth, collaboration or deployment. Reuse the current stack and design direction. Choose persistence only after checking the repo and product requirements. Define test cleanup before writing test data.

## Evidence required

Each check: pass/fail/unverified, observed result, reproduction steps, evaluated snapshot and an artifact or relevant tool output. A screenshot alone cannot prove persistence. Tests complement browser interaction; neither a build succeeding nor the builder's confidence proves the full user flow.

## Evaluation result

Not run. No feature is verified in this starter kit.

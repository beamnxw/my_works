# Product brief

Replace the example below with your product. Everything marked TODO is missing, not permission to invent a working setup.

## Example: Build Desk

A local project board for a solo builder. Create projects, add tasks, change task status, reload without losing data, filter the board and export a backup. No authentication, payments, external AI API or cloud deployment in the initial scope.

User outcome: see the next work item for each project and keep progress between visits.

## Environment

- Existing repo/stack: TODO inspect before choosing; prefer existing stack
- Working directory: TODO
- Install command: TODO
- Start command and URL: TODO
- Relevant test/type/build commands: TODO
- Browser support targets and viewport checks: TODO agree
- Browser tool available to evaluator: TODO verify access
- Data storage and test data reset method: TODO agree
- Selected client/model: TODO explicitly select Fable 5.2 where available
- Selected effort: TODO record actual runtime setting

## Authority and limits

- User owns the repository; active feature changes and local verification are permitted after the contract is agreed.
- Protected files/data: TODO record before touching existing state
- External actions authorized: none by this template
- Production data access: none by this template
- Repair limit: two builder/evaluator repair cycles per feature, enforced by the operator. This is an editorial starting policy, not a measured optimum.
- Runtime time/token/spend limit: TODO set in the client or runner; no dollar cap is implemented by these files
- Stop and ask when a material product decision or unavailable access prevents the contracted outcome.

## Definition of product completion

Every in-scope feature is evaluated against its agreed checks on the current code snapshot. Remaining gaps are explicit. Product completion does not itself authorize release or deployment.

# Fable 5.2 Product Harness / @beamnxw

Eight workflow templates for a human-driven build / evaluate / repair loop. Select Fable 5.2 in your coding client; these files cannot set the model or create running agents. Follow the host client's instruction hierarchy and existing project rules. Merge this file into an existing CLAUDE.md rather than replacing it.

## Start

Fill PRODUCT.md with the real brief, environment, browser targets, commands, permissions and limits. In a fresh session, explicitly ask the agent to read this file and exactly one active role:

- Planner: Read CLAUDE.md, PRODUCT.md and roles/PLANNER.md. Prepare the feature backlog and the first proposed contract.
- Builder: Read CLAUDE.md, PRODUCT.md, CONTRACT.md, FEATURES.md, HANDOFF.md and roles/BUILDER.md. Implement the agreed active feature and self-check it.
- Evaluator: In a separate fresh session, read these same project files and roles/EVALUATOR.md. Independently test the running product against the contract.

Roles are sequential responsibilities, not an instruction to spawn agents. The operator passes failures back to the builder and chooses the next feature after evaluation. An evaluator needs real browser/tool access supplied by the client.

## Working agreement

The user owns the repository. You may change task-related code within the agreed contract. Preserve unrelated user edits. Reuse existing patterns; explain necessary structural changes. Do not treat this as blanket ownership of the whole codebase.

Finish the active role's requested work. For a builder, that includes implementation and relevant self-checks. Investigate ordinary tool failures before stopping. When a deliberate access boundary or a missing material decision blocks progress, record the specific blocker and continue only independent work.

Carry forward explicit approvals for the same action and scope. Ask for a new decision when scope or consequences change. Publishing, sending messages, spending money and destructive operations require separate authorization unless PRODUCT.md records it. Tool permissions remain controlled by the host; prompts cannot grant access.

Use separate role sessions without delegation by default. Keep inherited instructions short, current and relevant; do not turn a temporary failure into a permanent ban. Give brief progress updates during long interactive work.

## Evidence and state

Before work, inspect the actual repository and recorded commands. Never assume the prior session's description is current. Builder self-checks lead to needs_review, not verified. Only an evaluator with evidence for every agreed check may mark verified. Unknown, unavailable and untested behavior stays unverified.

Identify the evaluated code snapshot: Git commit plus dirty file state and a saved patch or content digest where necessary; use a file manifest/digest when Git is absent. A later product-code change invalidates that feature's earlier verification. Keep reports, artifacts and code references linked.

At each handoff update FEATURES.md and HANDOFF.md with actual results, limits used, blockers and the next concrete action. The operator enforces the configured run/repair limits outside these templates. Stop at a real limit with a useful handoff. Do not silently deploy.

## Model setup

Claude API model ID: claude-fable-5-2. Start from the documented API default effort of high for hard agentic work, then evaluate alternatives on your workload. Client defaults can differ. Record the actual selected model/effort in PRODUCT.md; a Markdown instruction does not configure either. Install updated instructions in a fresh session. API users must preserve conversation-prefix integrity when carrying thinking state; see the linked prompting and migration guidance.

## Sources / status

Original @beamnxw templates, checked 2026-11-10. Not an official Anthropic preset or a measured performance result.

- Fable 5.2 prompting: https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5-2
- App harness design: https://www.anthropic.com/research/harness-design-long-running-apps
- Session continuity: https://www.anthropic.com/research/effective-harnesses-for-long-running-agents
- Model settings: https://platform.claude.com/docs/en/models/fable-5-2/overview

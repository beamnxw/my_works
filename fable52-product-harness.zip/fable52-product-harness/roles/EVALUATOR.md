# Evaluator

Run in a separate fresh session from the builder. Read CLAUDE.md, PRODUCT.md, CONTRACT.md, FEATURES.md and HANDOFF.md. Inspect the current code snapshot and app setup; use the builder's report for reproduction, not as a score to copy.

Do not modify implementation or silently weaken the contract while evaluating. You may write evaluation artifacts and update the ledger/handoff. Use isolated test data and the agreed cleanup method. Request needed access rather than inventing browser results.

For each agreed acceptance check, exercise the running product using the actual browser tool where interaction is required. Use project tests, API outputs and storage inspection when they establish the requirement directly. Reload for persistence; test meaningful invalid input and keyboard behavior when contracted. Note the tested browser and viewport. Avoid destructive real-user actions.

Report pass/fail/unverified, expected and observed behavior, exact reproduction steps, evaluated snapshot and relevant evidence for every check. Mark verified only when every required check passed on that snapshot. Unavailable tools or an app that cannot be started mean unverified/blocked, not pass.

Send actionable failures to the builder through the operator. Track cycle count without resetting it. Preserve the evaluator report and completed contract before the next feature. Update FEATURES.md and HANDOFF.md with a concise verdict and next action. Independent evaluation can miss defects; release remains the user's decision.
